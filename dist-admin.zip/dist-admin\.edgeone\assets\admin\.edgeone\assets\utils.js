// ==================== 工具函数 ====================

function showModal(title, body, onSubmit, cancelText = '取消') {
  document.getElementById('modal-title').textContent = title
  document.getElementById('modal-body').innerHTML = body
  document.getElementById('modal').classList.add('active')
  
  const submitBtn = document.getElementById('modal-submit')
  submitBtn.onclick = onSubmit
  submitBtn.style.display = onSubmit ? 'block' : 'none'
  
  // 修改取消按钮文本
  const cancelBtn = document.querySelector('.modal-footer .btn-secondary')
  cancelBtn.textContent = cancelText
  cancelBtn.onclick = closeModal
}

function closeModal() {
  document.getElementById('modal').classList.remove('active')
}

function showAlert(message, type = 'success') {
  const alertDiv = document.createElement('div')
  alertDiv.className = `alert alert-${type}`
  alertDiv.textContent = message
  
  document.querySelector('.content-area').insertBefore(alertDiv, document.querySelector('.content-area').firstChild)
  
  setTimeout(() => {
    alertDiv.remove()
  }, 3000)
}

function formatDateTime(dateStr) {
  if (!dateStr) return '-'
  const date = new Date(dateStr)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

function formatDate(date) {
  return date.toISOString().split('T')[0]
}

function isToday(dateStr) {
  if (!dateStr) return false
  const date = new Date(dateStr)
  const today = new Date()
  return date.toDateString() === today.toDateString()
}

function isThisMonth(dateStr) {
  if (!dateStr) return false
  const date = new Date(dateStr)
  const today = new Date()
  return date.getMonth() === today.getMonth() && date.getFullYear() === today.getFullYear()
}

// 点击模态框外部关闭
document.getElementById('modal').addEventListener('click', (e) => {
  if (e.target.id === 'modal') {
    closeModal()
  }
})
