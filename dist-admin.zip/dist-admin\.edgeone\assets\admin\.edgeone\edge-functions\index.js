
      let global = globalThis;

      class MessageChannel {
        constructor() {
          this.port1 = new MessagePort();
          this.port2 = new MessagePort();
        }
      }
      class MessagePort {
        constructor() {
          this.onmessage = null;
        }
        postMessage(data) {
          if (this.onmessage) {
            setTimeout(() => this.onmessage({ data }), 0);
          }
        }
      }
      global.MessageChannel = MessageChannel;

      async function handleRequest(context){
        let routeParams = {};
        let pagesFunctionResponse = null;
        const request = context.request;
        const waitUntil = context.waitUntil;
        const urlInfo = new URL(request.url);

        if (urlInfo.pathname !== '/' && urlInfo.pathname.endsWith('/')) {
          urlInfo.pathname = urlInfo.pathname.slice(0, -1);
        }

        let matchedFunc = false;
        
          if(!matchedFunc && '/helloworld-edge' === urlInfo.pathname) {
            matchedFunc = true;
              (() => {
  // edge-functions/helloworld-edge/index.js
  function onRequest(context) {
    const json = JSON.stringify({
      "code": 0,
      "message": "Hello World"
    });
    return new Response(json, {
      headers: {
        "content-type": "application/json",
        "x-edgefunctions": "Welcome to use EdgeOne Pages Functions."
      }
    });
  }

        pagesFunctionResponse = onRequest;
      })();
          }
        

        const params = {};
        if (routeParams.id) {
          if (routeParams.mode === 1) {
            const value = urlInfo.pathname.match(routeParams.left);        
            for (let i = 1; i < value.length; i++) {
              params[routeParams.id[i - 1]] = value[i];
            }
          } else {
            const value = urlInfo.pathname.replace(routeParams.left, '');
            const splitedValue = value.split('/');
            if (splitedValue.length === 1) {
              params[routeParams.id] = splitedValue[0];
            } else {
              params[routeParams.id] = splitedValue;
            }
          }
          
        }
        if(!matchedFunc){
          pagesFunctionResponse = function() {
            return new Response(null, {
              status: 404,
              headers: {
                "content-type": "text/html; charset=UTF-8",
                "x-edgefunctions-test": "Welcome to use Pages Functions.",
              },
            });
          }
        }
        return pagesFunctionResponse({request, params, env: {"AHA_CHROME_CRASHPAD_PIPE_NAME":"\\\\.\\pipe\\crashpad_7400_LAHUNESWHWOLKHMN","AI_AGENT":"TRAE","ALLUSERSPROFILE":"C:\\ProgramData","APPDATA":"C:\\Users\\13334\\AppData\\Roaming","asl.log":"Destination=file","BUNDLED_DEBUGPY_PATH":"c:\\Users\\13334\\.trae-cn\\extensions\\ms-python.debugpy-2025.18.0-win32-x64\\bundled\\libs\\debugpy","ChocolateyInstall":"C:\\ProgramData\\chocolatey","ChocolateyLastPathUpdate":"134103469288489749","COLORTERM":"truecolor","CommonProgramFiles":"C:\\Program Files\\Common Files","CommonProgramFiles(x86)":"C:\\Program Files (x86)\\Common Files","CommonProgramW6432":"C:\\Program Files\\Common Files","COMPUTERNAME":"ADMINISTRATOR","ComSpec":"C:\\WINDOWS\\system32\\cmd.exe","DriverData":"C:\\Windows\\System32\\Drivers\\DriverData","EFC_2372_1262719628":"1","EFC_2372_1592913036":"1","EFC_2372_2283032206":"1","EFC_2372_2775293581":"1","EFC_2372_3789132940":"1","GIT_ASKPASS":"d:\\Program Files\\TRAE CN\\resources\\app\\extensions\\git\\dist\\askpass.sh","HOMEDRIVE":"C:","HOMEPATH":"\\Users\\13334","isArchMatched":"1","LANG":"zh_CN.UTF-8","LOCALAPPDATA":"C:\\Users\\13334\\AppData\\Local","LOGONSERVER":"\\\\ADMINISTRATOR","NUMBER_OF_PROCESSORS":"8","OneDrive":"C:\\Users\\13334\\OneDrive","ORIGINAL_XDG_CURRENT_DESKTOP":"undefined","OS":"Windows_NT","Path":"c:\\\\Users\\\\13334\\\\.trae-cn\\\\sdks\\\\workspaces\\\\46067adf\\\\versions\\\\node\\\\current;c:\\\\Users\\\\13334\\\\.trae-cn\\\\sdks\\\\versions\\\\node\\\\current;c:\\Users\\13334\\.trae-cn\\sdks\\workspaces\\46067adf\\versions\\node\\current;c:\\Users\\13334\\.trae-cn\\sdks\\versions\\node\\current;C:\\WINDOWS\\system32;C:\\WINDOWS;C:\\WINDOWS\\System32\\Wbem;C:\\WINDOWS\\System32\\WindowsPowerShell\\v1.0\\;C:\\WINDOWS\\System32\\OpenSSH\\;D:\\Program Files\\Git\\cmd;D:\\Program Files\\supabase-cli-03a9671;D:\\Program Files\\nodejs\\;C:\\ProgramData\\chocolatey\\bin;d:\\Program Files\\Trae CN\\bin;D:\\Program Files\\Python\\Python313\\Scripts\\;D:\\Program Files\\Python\\Python313\\;C:\\Users\\13334\\AppData\\Local\\Microsoft\\WindowsApps;D:\\Program Files\\Qoder\\bin;C:\\Users\\13334\\AppData\\Roaming\\npm;D:\\Program Files\\CodeBuddy\\bin;c:\\Users\\13334\\.trae-cn\\extensions\\ms-python.debugpy-2025.18.0-win32-x64\\bundled\\scripts\\noConfigScripts","PATHEXT":".COM;.EXE;.BAT;.CMD;.VBS;.VBE;.JS;.JSE;.WSF;.WSH;.MSC;.CPL","PROCESSOR_ARCHITECTURE":"AMD64","PROCESSOR_IDENTIFIER":"Intel64 Family 6 Model 126 Stepping 5, GenuineIntel","PROCESSOR_LEVEL":"6","PROCESSOR_REVISION":"7e05","ProgramData":"C:\\ProgramData","ProgramFiles":"C:\\Program Files","ProgramFiles(x86)":"C:\\Program Files (x86)","ProgramW6432":"C:\\Program Files","PSModulePath":"C:\\Users\\13334\\Documents\\WindowsPowerShell\\Modules;C:\\Program Files\\WindowsPowerShell\\Modules;C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\Modules","PUBLIC":"C:\\Users\\Public","PYDEVD_DISABLE_FILE_VALIDATION":"1","PYTHONSTARTUP":"c:\\Users\\13334\\AppData\\Roaming\\Trae CN\\User\\workspaceStorage\\46067adfb220efc07092eb80db18eee4\\ms-python.python\\pythonrc.py","PYTHON_BASIC_REPL":"1","SAFE_RM_ALLOWED_PATH":"d:\\app-84zvdc9gufwh","SAFE_RM_AUTO_ADD_TEMP":"1","SAFE_RM_DENIED_PATH":"d:\\app-84zvdc9gufwh\\.vscode;d:\\app-84zvdc9gufwh\\.trae;d:\\app-84zvdc9gufwh\\.git","SAFE_RM_PROTECTION_FLAG":"c:\\Users\\13334\\AppData\\Local\\Temp\\safe-rm-protection-flag-98a02090-72d6-4cc6-af5b-ed720594d96e","SAFE_RM_SOURCE_FLAG":"c:\\Users\\13334\\AppData\\Local\\Temp\\safe-rm-source-flag-9d07ab45-5089-4f40-8d97-df0708b568bd","SESSIONNAME":"Console","SystemDrive":"C:","SystemRoot":"C:\\WINDOWS","TEMP":"C:\\Users\\13334\\AppData\\Local\\Temp","TERM_PRODUCT":"Trae","TERM_PROGRAM":"vscode","TERM_PROGRAM_VERSION":"1.104.3","TMP":"C:\\Users\\13334\\AppData\\Local\\Temp","TRAE_AI_SHELL_ID":"3","TRAE_SANDBOX_CLI_PATH":"d:\\Program Files\\TRAE CN\\resources\\app\\modules\\sandbox\\trae-sandbox.exe","TRAE_SANDBOX_CONFIG_NAME":"6944386f5d1304a721471870","TRAE_SANDBOX_SOURCE_FLAG_PATH":"c:\\Users\\13334\\AppData\\Local\\Temp\\sandbox-source-flag-f3705d7d-38f4-494a-88e9-d0347071386f","TRAE_SANDBOX_STORAGE_PATH":"C:\\Users\\13334\\AppData\\Roaming\\Trae CN\\ModularData\\ai-agent\\sandbox","USERDOMAIN":"ADMINISTRATOR","USERDOMAIN_ROAMINGPROFILE":"ADMINISTRATOR","USERNAME":"13334","USERPROFILE":"C:\\Users\\13334","VSCODE_DEBUGPY_ADAPTER_ENDPOINTS":"c:\\Users\\13334\\.trae-cn\\extensions\\ms-python.debugpy-2025.18.0-win32-x64\\.noConfigDebugAdapterEndpoints\\endpoint-b481a3ef3cb0f0f8.txt","VSCODE_GIT_ASKPASS_EXTRA_ARGS":"","VSCODE_GIT_ASKPASS_MAIN":"d:\\Program Files\\TRAE CN\\resources\\app\\extensions\\git\\dist\\askpass-main.js","VSCODE_GIT_ASKPASS_NODE":"D:\\Program Files\\TRAE CN\\Trae CN.exe","VSCODE_GIT_IPC_HANDLE":"\\\\.\\pipe\\vscode-git-5a4b5b6198-sock","VSCODE_INJECTION":"1","VSCODE_PYTHON_AUTOACTIVATE_GUARD":"1","windir":"C:\\WINDOWS","ZES_ENABLE_SYSMAN":"1"}, waitUntil });
      }
      addEventListener('fetch', event=>{return event.respondWith(handleRequest({request:event.request,params: {}, env: {"AHA_CHROME_CRASHPAD_PIPE_NAME":"\\\\.\\pipe\\crashpad_7400_LAHUNESWHWOLKHMN","AI_AGENT":"TRAE","ALLUSERSPROFILE":"C:\\ProgramData","APPDATA":"C:\\Users\\13334\\AppData\\Roaming","asl.log":"Destination=file","BUNDLED_DEBUGPY_PATH":"c:\\Users\\13334\\.trae-cn\\extensions\\ms-python.debugpy-2025.18.0-win32-x64\\bundled\\libs\\debugpy","ChocolateyInstall":"C:\\ProgramData\\chocolatey","ChocolateyLastPathUpdate":"134103469288489749","COLORTERM":"truecolor","CommonProgramFiles":"C:\\Program Files\\Common Files","CommonProgramFiles(x86)":"C:\\Program Files (x86)\\Common Files","CommonProgramW6432":"C:\\Program Files\\Common Files","COMPUTERNAME":"ADMINISTRATOR","ComSpec":"C:\\WINDOWS\\system32\\cmd.exe","DriverData":"C:\\Windows\\System32\\Drivers\\DriverData","EFC_2372_1262719628":"1","EFC_2372_1592913036":"1","EFC_2372_2283032206":"1","EFC_2372_2775293581":"1","EFC_2372_3789132940":"1","GIT_ASKPASS":"d:\\Program Files\\TRAE CN\\resources\\app\\extensions\\git\\dist\\askpass.sh","HOMEDRIVE":"C:","HOMEPATH":"\\Users\\13334","isArchMatched":"1","LANG":"zh_CN.UTF-8","LOCALAPPDATA":"C:\\Users\\13334\\AppData\\Local","LOGONSERVER":"\\\\ADMINISTRATOR","NUMBER_OF_PROCESSORS":"8","OneDrive":"C:\\Users\\13334\\OneDrive","ORIGINAL_XDG_CURRENT_DESKTOP":"undefined","OS":"Windows_NT","Path":"c:\\\\Users\\\\13334\\\\.trae-cn\\\\sdks\\\\workspaces\\\\46067adf\\\\versions\\\\node\\\\current;c:\\\\Users\\\\13334\\\\.trae-cn\\\\sdks\\\\versions\\\\node\\\\current;c:\\Users\\13334\\.trae-cn\\sdks\\workspaces\\46067adf\\versions\\node\\current;c:\\Users\\13334\\.trae-cn\\sdks\\versions\\node\\current;C:\\WINDOWS\\system32;C:\\WINDOWS;C:\\WINDOWS\\System32\\Wbem;C:\\WINDOWS\\System32\\WindowsPowerShell\\v1.0\\;C:\\WINDOWS\\System32\\OpenSSH\\;D:\\Program Files\\Git\\cmd;D:\\Program Files\\supabase-cli-03a9671;D:\\Program Files\\nodejs\\;C:\\ProgramData\\chocolatey\\bin;d:\\Program Files\\Trae CN\\bin;D:\\Program Files\\Python\\Python313\\Scripts\\;D:\\Program Files\\Python\\Python313\\;C:\\Users\\13334\\AppData\\Local\\Microsoft\\WindowsApps;D:\\Program Files\\Qoder\\bin;C:\\Users\\13334\\AppData\\Roaming\\npm;D:\\Program Files\\CodeBuddy\\bin;c:\\Users\\13334\\.trae-cn\\extensions\\ms-python.debugpy-2025.18.0-win32-x64\\bundled\\scripts\\noConfigScripts","PATHEXT":".COM;.EXE;.BAT;.CMD;.VBS;.VBE;.JS;.JSE;.WSF;.WSH;.MSC;.CPL","PROCESSOR_ARCHITECTURE":"AMD64","PROCESSOR_IDENTIFIER":"Intel64 Family 6 Model 126 Stepping 5, GenuineIntel","PROCESSOR_LEVEL":"6","PROCESSOR_REVISION":"7e05","ProgramData":"C:\\ProgramData","ProgramFiles":"C:\\Program Files","ProgramFiles(x86)":"C:\\Program Files (x86)","ProgramW6432":"C:\\Program Files","PSModulePath":"C:\\Users\\13334\\Documents\\WindowsPowerShell\\Modules;C:\\Program Files\\WindowsPowerShell\\Modules;C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\Modules","PUBLIC":"C:\\Users\\Public","PYDEVD_DISABLE_FILE_VALIDATION":"1","PYTHONSTARTUP":"c:\\Users\\13334\\AppData\\Roaming\\Trae CN\\User\\workspaceStorage\\46067adfb220efc07092eb80db18eee4\\ms-python.python\\pythonrc.py","PYTHON_BASIC_REPL":"1","SAFE_RM_ALLOWED_PATH":"d:\\app-84zvdc9gufwh","SAFE_RM_AUTO_ADD_TEMP":"1","SAFE_RM_DENIED_PATH":"d:\\app-84zvdc9gufwh\\.vscode;d:\\app-84zvdc9gufwh\\.trae;d:\\app-84zvdc9gufwh\\.git","SAFE_RM_PROTECTION_FLAG":"c:\\Users\\13334\\AppData\\Local\\Temp\\safe-rm-protection-flag-98a02090-72d6-4cc6-af5b-ed720594d96e","SAFE_RM_SOURCE_FLAG":"c:\\Users\\13334\\AppData\\Local\\Temp\\safe-rm-source-flag-9d07ab45-5089-4f40-8d97-df0708b568bd","SESSIONNAME":"Console","SystemDrive":"C:","SystemRoot":"C:\\WINDOWS","TEMP":"C:\\Users\\13334\\AppData\\Local\\Temp","TERM_PRODUCT":"Trae","TERM_PROGRAM":"vscode","TERM_PROGRAM_VERSION":"1.104.3","TMP":"C:\\Users\\13334\\AppData\\Local\\Temp","TRAE_AI_SHELL_ID":"3","TRAE_SANDBOX_CLI_PATH":"d:\\Program Files\\TRAE CN\\resources\\app\\modules\\sandbox\\trae-sandbox.exe","TRAE_SANDBOX_CONFIG_NAME":"6944386f5d1304a721471870","TRAE_SANDBOX_SOURCE_FLAG_PATH":"c:\\Users\\13334\\AppData\\Local\\Temp\\sandbox-source-flag-f3705d7d-38f4-494a-88e9-d0347071386f","TRAE_SANDBOX_STORAGE_PATH":"C:\\Users\\13334\\AppData\\Roaming\\Trae CN\\ModularData\\ai-agent\\sandbox","USERDOMAIN":"ADMINISTRATOR","USERDOMAIN_ROAMINGPROFILE":"ADMINISTRATOR","USERNAME":"13334","USERPROFILE":"C:\\Users\\13334","VSCODE_DEBUGPY_ADAPTER_ENDPOINTS":"c:\\Users\\13334\\.trae-cn\\extensions\\ms-python.debugpy-2025.18.0-win32-x64\\.noConfigDebugAdapterEndpoints\\endpoint-b481a3ef3cb0f0f8.txt","VSCODE_GIT_ASKPASS_EXTRA_ARGS":"","VSCODE_GIT_ASKPASS_MAIN":"d:\\Program Files\\TRAE CN\\resources\\app\\extensions\\git\\dist\\askpass-main.js","VSCODE_GIT_ASKPASS_NODE":"D:\\Program Files\\TRAE CN\\Trae CN.exe","VSCODE_GIT_IPC_HANDLE":"\\\\.\\pipe\\vscode-git-5a4b5b6198-sock","VSCODE_INJECTION":"1","VSCODE_PYTHON_AUTOACTIVATE_GUARD":"1","windir":"C:\\WINDOWS","ZES_ENABLE_SYSMAN":"1"}, waitUntil: event.waitUntil }))});